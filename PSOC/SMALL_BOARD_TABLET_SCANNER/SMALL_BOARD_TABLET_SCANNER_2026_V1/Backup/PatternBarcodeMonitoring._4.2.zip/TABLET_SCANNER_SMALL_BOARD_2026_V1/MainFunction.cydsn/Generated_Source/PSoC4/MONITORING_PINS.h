/***************************************************************************//**
* \file MONITORING_PINS.h
* \version 4.0
*
* \brief
*  This file provides constants and parameter values for the pin components
*  buried into SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PINS_MONITORING_H)
#define CY_SCB_PINS_MONITORING_H

#include "cydevice_trm.h"
#include "cyfitter.h"
#include "cytypes.h"


/***************************************
*   Conditional Compilation Parameters
****************************************/

/* Unconfigured pins */
#define MONITORING_REMOVE_RX_WAKE_SCL_MOSI_PIN  (1u)
#define MONITORING_REMOVE_RX_SCL_MOSI_PIN      (1u)
#define MONITORING_REMOVE_TX_SDA_MISO_PIN      (1u)
#define MONITORING_REMOVE_CTS_SCLK_PIN      (1u)
#define MONITORING_REMOVE_RTS_SS0_PIN      (1u)
#define MONITORING_REMOVE_SS1_PIN                 (1u)
#define MONITORING_REMOVE_SS2_PIN                 (1u)
#define MONITORING_REMOVE_SS3_PIN                 (1u)

/* Mode defined pins */
#define MONITORING_REMOVE_I2C_PINS                (1u)
#define MONITORING_REMOVE_SPI_MASTER_PINS         (1u)
#define MONITORING_REMOVE_SPI_MASTER_SCLK_PIN     (1u)
#define MONITORING_REMOVE_SPI_MASTER_MOSI_PIN     (1u)
#define MONITORING_REMOVE_SPI_MASTER_MISO_PIN     (1u)
#define MONITORING_REMOVE_SPI_MASTER_SS0_PIN      (1u)
#define MONITORING_REMOVE_SPI_MASTER_SS1_PIN      (1u)
#define MONITORING_REMOVE_SPI_MASTER_SS2_PIN      (1u)
#define MONITORING_REMOVE_SPI_MASTER_SS3_PIN      (1u)
#define MONITORING_REMOVE_SPI_SLAVE_PINS          (1u)
#define MONITORING_REMOVE_SPI_SLAVE_MOSI_PIN      (1u)
#define MONITORING_REMOVE_SPI_SLAVE_MISO_PIN      (1u)
#define MONITORING_REMOVE_UART_TX_PIN             (0u)
#define MONITORING_REMOVE_UART_RX_TX_PIN          (1u)
#define MONITORING_REMOVE_UART_RX_PIN             (0u)
#define MONITORING_REMOVE_UART_RX_WAKE_PIN        (1u)
#define MONITORING_REMOVE_UART_RTS_PIN            (1u)
#define MONITORING_REMOVE_UART_CTS_PIN            (1u)

/* Unconfigured pins */
#define MONITORING_RX_WAKE_SCL_MOSI_PIN (0u == MONITORING_REMOVE_RX_WAKE_SCL_MOSI_PIN)
#define MONITORING_RX_SCL_MOSI_PIN     (0u == MONITORING_REMOVE_RX_SCL_MOSI_PIN)
#define MONITORING_TX_SDA_MISO_PIN     (0u == MONITORING_REMOVE_TX_SDA_MISO_PIN)
#define MONITORING_CTS_SCLK_PIN     (0u == MONITORING_REMOVE_CTS_SCLK_PIN)
#define MONITORING_RTS_SS0_PIN     (0u == MONITORING_REMOVE_RTS_SS0_PIN)
#define MONITORING_SS1_PIN                (0u == MONITORING_REMOVE_SS1_PIN)
#define MONITORING_SS2_PIN                (0u == MONITORING_REMOVE_SS2_PIN)
#define MONITORING_SS3_PIN                (0u == MONITORING_REMOVE_SS3_PIN)

/* Mode defined pins */
#define MONITORING_I2C_PINS               (0u == MONITORING_REMOVE_I2C_PINS)
#define MONITORING_SPI_MASTER_PINS        (0u == MONITORING_REMOVE_SPI_MASTER_PINS)
#define MONITORING_SPI_MASTER_SCLK_PIN    (0u == MONITORING_REMOVE_SPI_MASTER_SCLK_PIN)
#define MONITORING_SPI_MASTER_MOSI_PIN    (0u == MONITORING_REMOVE_SPI_MASTER_MOSI_PIN)
#define MONITORING_SPI_MASTER_MISO_PIN    (0u == MONITORING_REMOVE_SPI_MASTER_MISO_PIN)
#define MONITORING_SPI_MASTER_SS0_PIN     (0u == MONITORING_REMOVE_SPI_MASTER_SS0_PIN)
#define MONITORING_SPI_MASTER_SS1_PIN     (0u == MONITORING_REMOVE_SPI_MASTER_SS1_PIN)
#define MONITORING_SPI_MASTER_SS2_PIN     (0u == MONITORING_REMOVE_SPI_MASTER_SS2_PIN)
#define MONITORING_SPI_MASTER_SS3_PIN     (0u == MONITORING_REMOVE_SPI_MASTER_SS3_PIN)
#define MONITORING_SPI_SLAVE_PINS         (0u == MONITORING_REMOVE_SPI_SLAVE_PINS)
#define MONITORING_SPI_SLAVE_MOSI_PIN     (0u == MONITORING_REMOVE_SPI_SLAVE_MOSI_PIN)
#define MONITORING_SPI_SLAVE_MISO_PIN     (0u == MONITORING_REMOVE_SPI_SLAVE_MISO_PIN)
#define MONITORING_UART_TX_PIN            (0u == MONITORING_REMOVE_UART_TX_PIN)
#define MONITORING_UART_RX_TX_PIN         (0u == MONITORING_REMOVE_UART_RX_TX_PIN)
#define MONITORING_UART_RX_PIN            (0u == MONITORING_REMOVE_UART_RX_PIN)
#define MONITORING_UART_RX_WAKE_PIN       (0u == MONITORING_REMOVE_UART_RX_WAKE_PIN)
#define MONITORING_UART_RTS_PIN           (0u == MONITORING_REMOVE_UART_RTS_PIN)
#define MONITORING_UART_CTS_PIN           (0u == MONITORING_REMOVE_UART_CTS_PIN)


/***************************************
*             Includes
****************************************/

#if (MONITORING_RX_WAKE_SCL_MOSI_PIN)
    #include "MONITORING_uart_rx_wake_i2c_scl_spi_mosi.h"
#endif /* (MONITORING_RX_SCL_MOSI) */

#if (MONITORING_RX_SCL_MOSI_PIN)
    #include "MONITORING_uart_rx_i2c_scl_spi_mosi.h"
#endif /* (MONITORING_RX_SCL_MOSI) */

#if (MONITORING_TX_SDA_MISO_PIN)
    #include "MONITORING_uart_tx_i2c_sda_spi_miso.h"
#endif /* (MONITORING_TX_SDA_MISO) */

#if (MONITORING_CTS_SCLK_PIN)
    #include "MONITORING_uart_cts_spi_sclk.h"
#endif /* (MONITORING_CTS_SCLK) */

#if (MONITORING_RTS_SS0_PIN)
    #include "MONITORING_uart_rts_spi_ss0.h"
#endif /* (MONITORING_RTS_SS0_PIN) */

#if (MONITORING_SS1_PIN)
    #include "MONITORING_spi_ss1.h"
#endif /* (MONITORING_SS1_PIN) */

#if (MONITORING_SS2_PIN)
    #include "MONITORING_spi_ss2.h"
#endif /* (MONITORING_SS2_PIN) */

#if (MONITORING_SS3_PIN)
    #include "MONITORING_spi_ss3.h"
#endif /* (MONITORING_SS3_PIN) */

#if (MONITORING_I2C_PINS)
    #include "MONITORING_scl.h"
    #include "MONITORING_sda.h"
#endif /* (MONITORING_I2C_PINS) */

#if (MONITORING_SPI_MASTER_PINS)
#if (MONITORING_SPI_MASTER_SCLK_PIN)
    #include "MONITORING_sclk_m.h"
#endif /* (MONITORING_SPI_MASTER_SCLK_PIN) */

#if (MONITORING_SPI_MASTER_MOSI_PIN)
    #include "MONITORING_mosi_m.h"
#endif /* (MONITORING_SPI_MASTER_MOSI_PIN) */

#if (MONITORING_SPI_MASTER_MISO_PIN)
    #include "MONITORING_miso_m.h"
#endif /*(MONITORING_SPI_MASTER_MISO_PIN) */
#endif /* (MONITORING_SPI_MASTER_PINS) */

#if (MONITORING_SPI_SLAVE_PINS)
    #include "MONITORING_sclk_s.h"
    #include "MONITORING_ss_s.h"

#if (MONITORING_SPI_SLAVE_MOSI_PIN)
    #include "MONITORING_mosi_s.h"
#endif /* (MONITORING_SPI_SLAVE_MOSI_PIN) */

#if (MONITORING_SPI_SLAVE_MISO_PIN)
    #include "MONITORING_miso_s.h"
#endif /*(MONITORING_SPI_SLAVE_MISO_PIN) */
#endif /* (MONITORING_SPI_SLAVE_PINS) */

#if (MONITORING_SPI_MASTER_SS0_PIN)
    #include "MONITORING_ss0_m.h"
#endif /* (MONITORING_SPI_MASTER_SS0_PIN) */

#if (MONITORING_SPI_MASTER_SS1_PIN)
    #include "MONITORING_ss1_m.h"
#endif /* (MONITORING_SPI_MASTER_SS1_PIN) */

#if (MONITORING_SPI_MASTER_SS2_PIN)
    #include "MONITORING_ss2_m.h"
#endif /* (MONITORING_SPI_MASTER_SS2_PIN) */

#if (MONITORING_SPI_MASTER_SS3_PIN)
    #include "MONITORING_ss3_m.h"
#endif /* (MONITORING_SPI_MASTER_SS3_PIN) */

#if (MONITORING_UART_TX_PIN)
    #include "MONITORING_tx.h"
#endif /* (MONITORING_UART_TX_PIN) */

#if (MONITORING_UART_RX_TX_PIN)
    #include "MONITORING_rx_tx.h"
#endif /* (MONITORING_UART_RX_TX_PIN) */

#if (MONITORING_UART_RX_PIN)
    #include "MONITORING_rx.h"
#endif /* (MONITORING_UART_RX_PIN) */

#if (MONITORING_UART_RX_WAKE_PIN)
    #include "MONITORING_rx_wake.h"
#endif /* (MONITORING_UART_RX_WAKE_PIN) */

#if (MONITORING_UART_RTS_PIN)
    #include "MONITORING_rts.h"
#endif /* (MONITORING_UART_RTS_PIN) */

#if (MONITORING_UART_CTS_PIN)
    #include "MONITORING_cts.h"
#endif /* (MONITORING_UART_CTS_PIN) */


/***************************************
*              Registers
***************************************/

#if (MONITORING_RX_SCL_MOSI_PIN)
    #define MONITORING_RX_SCL_MOSI_HSIOM_REG   (*(reg32 *) MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM)
    #define MONITORING_RX_SCL_MOSI_HSIOM_PTR   ( (reg32 *) MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM)
    
    #define MONITORING_RX_SCL_MOSI_HSIOM_MASK      (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_MASK)
    #define MONITORING_RX_SCL_MOSI_HSIOM_POS       (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_SHIFT)
    #define MONITORING_RX_SCL_MOSI_HSIOM_SEL_GPIO  (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_GPIO)
    #define MONITORING_RX_SCL_MOSI_HSIOM_SEL_I2C   (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_I2C)
    #define MONITORING_RX_SCL_MOSI_HSIOM_SEL_SPI   (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_SPI)
    #define MONITORING_RX_SCL_MOSI_HSIOM_SEL_UART  (MONITORING_uart_rx_i2c_scl_spi_mosi__0__HSIOM_UART)
    
#elif (MONITORING_RX_WAKE_SCL_MOSI_PIN)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG   (*(reg32 *) MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_PTR   ( (reg32 *) MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM)
    
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_MASK      (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_MASK)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_POS       (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_SHIFT)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_SEL_GPIO  (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_GPIO)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_SEL_I2C   (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_I2C)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_SEL_SPI   (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_SPI)
    #define MONITORING_RX_WAKE_SCL_MOSI_HSIOM_SEL_UART  (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_UART)    
   
    #define MONITORING_RX_WAKE_SCL_MOSI_INTCFG_REG (*(reg32 *) MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__INTCFG)
    #define MONITORING_RX_WAKE_SCL_MOSI_INTCFG_PTR ( (reg32 *) MONITORING_uart_rx_wake_i2c_scl_spi_mosi__0__INTCFG)
    #define MONITORING_RX_WAKE_SCL_MOSI_INTCFG_TYPE_POS  (MONITORING_uart_rx_wake_i2c_scl_spi_mosi__SHIFT)
    #define MONITORING_RX_WAKE_SCL_MOSI_INTCFG_TYPE_MASK ((uint32) MONITORING_INTCFG_TYPE_MASK << \
                                                                           MONITORING_RX_WAKE_SCL_MOSI_INTCFG_TYPE_POS)
#else
    /* None of pins MONITORING_RX_SCL_MOSI_PIN or MONITORING_RX_WAKE_SCL_MOSI_PIN present.*/
#endif /* (MONITORING_RX_SCL_MOSI_PIN) */

#if (MONITORING_TX_SDA_MISO_PIN)
    #define MONITORING_TX_SDA_MISO_HSIOM_REG   (*(reg32 *) MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM)
    #define MONITORING_TX_SDA_MISO_HSIOM_PTR   ( (reg32 *) MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM)
    
    #define MONITORING_TX_SDA_MISO_HSIOM_MASK      (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_MASK)
    #define MONITORING_TX_SDA_MISO_HSIOM_POS       (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_SHIFT)
    #define MONITORING_TX_SDA_MISO_HSIOM_SEL_GPIO  (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_GPIO)
    #define MONITORING_TX_SDA_MISO_HSIOM_SEL_I2C   (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_I2C)
    #define MONITORING_TX_SDA_MISO_HSIOM_SEL_SPI   (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_SPI)
    #define MONITORING_TX_SDA_MISO_HSIOM_SEL_UART  (MONITORING_uart_tx_i2c_sda_spi_miso__0__HSIOM_UART)
#endif /* (MONITORING_TX_SDA_MISO_PIN) */

#if (MONITORING_CTS_SCLK_PIN)
    #define MONITORING_CTS_SCLK_HSIOM_REG   (*(reg32 *) MONITORING_uart_cts_spi_sclk__0__HSIOM)
    #define MONITORING_CTS_SCLK_HSIOM_PTR   ( (reg32 *) MONITORING_uart_cts_spi_sclk__0__HSIOM)
    
    #define MONITORING_CTS_SCLK_HSIOM_MASK      (MONITORING_uart_cts_spi_sclk__0__HSIOM_MASK)
    #define MONITORING_CTS_SCLK_HSIOM_POS       (MONITORING_uart_cts_spi_sclk__0__HSIOM_SHIFT)
    #define MONITORING_CTS_SCLK_HSIOM_SEL_GPIO  (MONITORING_uart_cts_spi_sclk__0__HSIOM_GPIO)
    #define MONITORING_CTS_SCLK_HSIOM_SEL_I2C   (MONITORING_uart_cts_spi_sclk__0__HSIOM_I2C)
    #define MONITORING_CTS_SCLK_HSIOM_SEL_SPI   (MONITORING_uart_cts_spi_sclk__0__HSIOM_SPI)
    #define MONITORING_CTS_SCLK_HSIOM_SEL_UART  (MONITORING_uart_cts_spi_sclk__0__HSIOM_UART)
#endif /* (MONITORING_CTS_SCLK_PIN) */

#if (MONITORING_RTS_SS0_PIN)
    #define MONITORING_RTS_SS0_HSIOM_REG   (*(reg32 *) MONITORING_uart_rts_spi_ss0__0__HSIOM)
    #define MONITORING_RTS_SS0_HSIOM_PTR   ( (reg32 *) MONITORING_uart_rts_spi_ss0__0__HSIOM)
    
    #define MONITORING_RTS_SS0_HSIOM_MASK      (MONITORING_uart_rts_spi_ss0__0__HSIOM_MASK)
    #define MONITORING_RTS_SS0_HSIOM_POS       (MONITORING_uart_rts_spi_ss0__0__HSIOM_SHIFT)
    #define MONITORING_RTS_SS0_HSIOM_SEL_GPIO  (MONITORING_uart_rts_spi_ss0__0__HSIOM_GPIO)
    #define MONITORING_RTS_SS0_HSIOM_SEL_I2C   (MONITORING_uart_rts_spi_ss0__0__HSIOM_I2C)
    #define MONITORING_RTS_SS0_HSIOM_SEL_SPI   (MONITORING_uart_rts_spi_ss0__0__HSIOM_SPI)
#if !(MONITORING_CY_SCBIP_V0 || MONITORING_CY_SCBIP_V1)
    #define MONITORING_RTS_SS0_HSIOM_SEL_UART  (MONITORING_uart_rts_spi_ss0__0__HSIOM_UART)
#endif /* !(MONITORING_CY_SCBIP_V0 || MONITORING_CY_SCBIP_V1) */
#endif /* (MONITORING_RTS_SS0_PIN) */

#if (MONITORING_SS1_PIN)
    #define MONITORING_SS1_HSIOM_REG  (*(reg32 *) MONITORING_spi_ss1__0__HSIOM)
    #define MONITORING_SS1_HSIOM_PTR  ( (reg32 *) MONITORING_spi_ss1__0__HSIOM)
    
    #define MONITORING_SS1_HSIOM_MASK     (MONITORING_spi_ss1__0__HSIOM_MASK)
    #define MONITORING_SS1_HSIOM_POS      (MONITORING_spi_ss1__0__HSIOM_SHIFT)
    #define MONITORING_SS1_HSIOM_SEL_GPIO (MONITORING_spi_ss1__0__HSIOM_GPIO)
    #define MONITORING_SS1_HSIOM_SEL_I2C  (MONITORING_spi_ss1__0__HSIOM_I2C)
    #define MONITORING_SS1_HSIOM_SEL_SPI  (MONITORING_spi_ss1__0__HSIOM_SPI)
#endif /* (MONITORING_SS1_PIN) */

#if (MONITORING_SS2_PIN)
    #define MONITORING_SS2_HSIOM_REG     (*(reg32 *) MONITORING_spi_ss2__0__HSIOM)
    #define MONITORING_SS2_HSIOM_PTR     ( (reg32 *) MONITORING_spi_ss2__0__HSIOM)
    
    #define MONITORING_SS2_HSIOM_MASK     (MONITORING_spi_ss2__0__HSIOM_MASK)
    #define MONITORING_SS2_HSIOM_POS      (MONITORING_spi_ss2__0__HSIOM_SHIFT)
    #define MONITORING_SS2_HSIOM_SEL_GPIO (MONITORING_spi_ss2__0__HSIOM_GPIO)
    #define MONITORING_SS2_HSIOM_SEL_I2C  (MONITORING_spi_ss2__0__HSIOM_I2C)
    #define MONITORING_SS2_HSIOM_SEL_SPI  (MONITORING_spi_ss2__0__HSIOM_SPI)
#endif /* (MONITORING_SS2_PIN) */

#if (MONITORING_SS3_PIN)
    #define MONITORING_SS3_HSIOM_REG     (*(reg32 *) MONITORING_spi_ss3__0__HSIOM)
    #define MONITORING_SS3_HSIOM_PTR     ( (reg32 *) MONITORING_spi_ss3__0__HSIOM)
    
    #define MONITORING_SS3_HSIOM_MASK     (MONITORING_spi_ss3__0__HSIOM_MASK)
    #define MONITORING_SS3_HSIOM_POS      (MONITORING_spi_ss3__0__HSIOM_SHIFT)
    #define MONITORING_SS3_HSIOM_SEL_GPIO (MONITORING_spi_ss3__0__HSIOM_GPIO)
    #define MONITORING_SS3_HSIOM_SEL_I2C  (MONITORING_spi_ss3__0__HSIOM_I2C)
    #define MONITORING_SS3_HSIOM_SEL_SPI  (MONITORING_spi_ss3__0__HSIOM_SPI)
#endif /* (MONITORING_SS3_PIN) */

#if (MONITORING_I2C_PINS)
    #define MONITORING_SCL_HSIOM_REG  (*(reg32 *) MONITORING_scl__0__HSIOM)
    #define MONITORING_SCL_HSIOM_PTR  ( (reg32 *) MONITORING_scl__0__HSIOM)
    
    #define MONITORING_SCL_HSIOM_MASK     (MONITORING_scl__0__HSIOM_MASK)
    #define MONITORING_SCL_HSIOM_POS      (MONITORING_scl__0__HSIOM_SHIFT)
    #define MONITORING_SCL_HSIOM_SEL_GPIO (MONITORING_sda__0__HSIOM_GPIO)
    #define MONITORING_SCL_HSIOM_SEL_I2C  (MONITORING_sda__0__HSIOM_I2C)
    
    #define MONITORING_SDA_HSIOM_REG  (*(reg32 *) MONITORING_sda__0__HSIOM)
    #define MONITORING_SDA_HSIOM_PTR  ( (reg32 *) MONITORING_sda__0__HSIOM)
    
    #define MONITORING_SDA_HSIOM_MASK     (MONITORING_sda__0__HSIOM_MASK)
    #define MONITORING_SDA_HSIOM_POS      (MONITORING_sda__0__HSIOM_SHIFT)
    #define MONITORING_SDA_HSIOM_SEL_GPIO (MONITORING_sda__0__HSIOM_GPIO)
    #define MONITORING_SDA_HSIOM_SEL_I2C  (MONITORING_sda__0__HSIOM_I2C)
#endif /* (MONITORING_I2C_PINS) */

#if (MONITORING_SPI_SLAVE_PINS)
    #define MONITORING_SCLK_S_HSIOM_REG   (*(reg32 *) MONITORING_sclk_s__0__HSIOM)
    #define MONITORING_SCLK_S_HSIOM_PTR   ( (reg32 *) MONITORING_sclk_s__0__HSIOM)
    
    #define MONITORING_SCLK_S_HSIOM_MASK      (MONITORING_sclk_s__0__HSIOM_MASK)
    #define MONITORING_SCLK_S_HSIOM_POS       (MONITORING_sclk_s__0__HSIOM_SHIFT)
    #define MONITORING_SCLK_S_HSIOM_SEL_GPIO  (MONITORING_sclk_s__0__HSIOM_GPIO)
    #define MONITORING_SCLK_S_HSIOM_SEL_SPI   (MONITORING_sclk_s__0__HSIOM_SPI)
    
    #define MONITORING_SS0_S_HSIOM_REG    (*(reg32 *) MONITORING_ss0_s__0__HSIOM)
    #define MONITORING_SS0_S_HSIOM_PTR    ( (reg32 *) MONITORING_ss0_s__0__HSIOM)
    
    #define MONITORING_SS0_S_HSIOM_MASK       (MONITORING_ss0_s__0__HSIOM_MASK)
    #define MONITORING_SS0_S_HSIOM_POS        (MONITORING_ss0_s__0__HSIOM_SHIFT)
    #define MONITORING_SS0_S_HSIOM_SEL_GPIO   (MONITORING_ss0_s__0__HSIOM_GPIO)  
    #define MONITORING_SS0_S_HSIOM_SEL_SPI    (MONITORING_ss0_s__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_SLAVE_PINS) */

#if (MONITORING_SPI_SLAVE_MOSI_PIN)
    #define MONITORING_MOSI_S_HSIOM_REG   (*(reg32 *) MONITORING_mosi_s__0__HSIOM)
    #define MONITORING_MOSI_S_HSIOM_PTR   ( (reg32 *) MONITORING_mosi_s__0__HSIOM)
    
    #define MONITORING_MOSI_S_HSIOM_MASK      (MONITORING_mosi_s__0__HSIOM_MASK)
    #define MONITORING_MOSI_S_HSIOM_POS       (MONITORING_mosi_s__0__HSIOM_SHIFT)
    #define MONITORING_MOSI_S_HSIOM_SEL_GPIO  (MONITORING_mosi_s__0__HSIOM_GPIO)
    #define MONITORING_MOSI_S_HSIOM_SEL_SPI   (MONITORING_mosi_s__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_SLAVE_MOSI_PIN) */

#if (MONITORING_SPI_SLAVE_MISO_PIN)
    #define MONITORING_MISO_S_HSIOM_REG   (*(reg32 *) MONITORING_miso_s__0__HSIOM)
    #define MONITORING_MISO_S_HSIOM_PTR   ( (reg32 *) MONITORING_miso_s__0__HSIOM)
    
    #define MONITORING_MISO_S_HSIOM_MASK      (MONITORING_miso_s__0__HSIOM_MASK)
    #define MONITORING_MISO_S_HSIOM_POS       (MONITORING_miso_s__0__HSIOM_SHIFT)
    #define MONITORING_MISO_S_HSIOM_SEL_GPIO  (MONITORING_miso_s__0__HSIOM_GPIO)
    #define MONITORING_MISO_S_HSIOM_SEL_SPI   (MONITORING_miso_s__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_SLAVE_MISO_PIN) */

#if (MONITORING_SPI_MASTER_MISO_PIN)
    #define MONITORING_MISO_M_HSIOM_REG   (*(reg32 *) MONITORING_miso_m__0__HSIOM)
    #define MONITORING_MISO_M_HSIOM_PTR   ( (reg32 *) MONITORING_miso_m__0__HSIOM)
    
    #define MONITORING_MISO_M_HSIOM_MASK      (MONITORING_miso_m__0__HSIOM_MASK)
    #define MONITORING_MISO_M_HSIOM_POS       (MONITORING_miso_m__0__HSIOM_SHIFT)
    #define MONITORING_MISO_M_HSIOM_SEL_GPIO  (MONITORING_miso_m__0__HSIOM_GPIO)
    #define MONITORING_MISO_M_HSIOM_SEL_SPI   (MONITORING_miso_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_MISO_PIN) */

#if (MONITORING_SPI_MASTER_MOSI_PIN)
    #define MONITORING_MOSI_M_HSIOM_REG   (*(reg32 *) MONITORING_mosi_m__0__HSIOM)
    #define MONITORING_MOSI_M_HSIOM_PTR   ( (reg32 *) MONITORING_mosi_m__0__HSIOM)
    
    #define MONITORING_MOSI_M_HSIOM_MASK      (MONITORING_mosi_m__0__HSIOM_MASK)
    #define MONITORING_MOSI_M_HSIOM_POS       (MONITORING_mosi_m__0__HSIOM_SHIFT)
    #define MONITORING_MOSI_M_HSIOM_SEL_GPIO  (MONITORING_mosi_m__0__HSIOM_GPIO)
    #define MONITORING_MOSI_M_HSIOM_SEL_SPI   (MONITORING_mosi_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_MOSI_PIN) */

#if (MONITORING_SPI_MASTER_SCLK_PIN)
    #define MONITORING_SCLK_M_HSIOM_REG   (*(reg32 *) MONITORING_sclk_m__0__HSIOM)
    #define MONITORING_SCLK_M_HSIOM_PTR   ( (reg32 *) MONITORING_sclk_m__0__HSIOM)
    
    #define MONITORING_SCLK_M_HSIOM_MASK      (MONITORING_sclk_m__0__HSIOM_MASK)
    #define MONITORING_SCLK_M_HSIOM_POS       (MONITORING_sclk_m__0__HSIOM_SHIFT)
    #define MONITORING_SCLK_M_HSIOM_SEL_GPIO  (MONITORING_sclk_m__0__HSIOM_GPIO)
    #define MONITORING_SCLK_M_HSIOM_SEL_SPI   (MONITORING_sclk_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_SCLK_PIN) */

#if (MONITORING_SPI_MASTER_SS0_PIN)
    #define MONITORING_SS0_M_HSIOM_REG    (*(reg32 *) MONITORING_ss0_m__0__HSIOM)
    #define MONITORING_SS0_M_HSIOM_PTR    ( (reg32 *) MONITORING_ss0_m__0__HSIOM)
    
    #define MONITORING_SS0_M_HSIOM_MASK       (MONITORING_ss0_m__0__HSIOM_MASK)
    #define MONITORING_SS0_M_HSIOM_POS        (MONITORING_ss0_m__0__HSIOM_SHIFT)
    #define MONITORING_SS0_M_HSIOM_SEL_GPIO   (MONITORING_ss0_m__0__HSIOM_GPIO)
    #define MONITORING_SS0_M_HSIOM_SEL_SPI    (MONITORING_ss0_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_SS0_PIN) */

#if (MONITORING_SPI_MASTER_SS1_PIN)
    #define MONITORING_SS1_M_HSIOM_REG    (*(reg32 *) MONITORING_ss1_m__0__HSIOM)
    #define MONITORING_SS1_M_HSIOM_PTR    ( (reg32 *) MONITORING_ss1_m__0__HSIOM)
    
    #define MONITORING_SS1_M_HSIOM_MASK       (MONITORING_ss1_m__0__HSIOM_MASK)
    #define MONITORING_SS1_M_HSIOM_POS        (MONITORING_ss1_m__0__HSIOM_SHIFT)
    #define MONITORING_SS1_M_HSIOM_SEL_GPIO   (MONITORING_ss1_m__0__HSIOM_GPIO)
    #define MONITORING_SS1_M_HSIOM_SEL_SPI    (MONITORING_ss1_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_SS1_PIN) */

#if (MONITORING_SPI_MASTER_SS2_PIN)
    #define MONITORING_SS2_M_HSIOM_REG    (*(reg32 *) MONITORING_ss2_m__0__HSIOM)
    #define MONITORING_SS2_M_HSIOM_PTR    ( (reg32 *) MONITORING_ss2_m__0__HSIOM)
    
    #define MONITORING_SS2_M_HSIOM_MASK       (MONITORING_ss2_m__0__HSIOM_MASK)
    #define MONITORING_SS2_M_HSIOM_POS        (MONITORING_ss2_m__0__HSIOM_SHIFT)
    #define MONITORING_SS2_M_HSIOM_SEL_GPIO   (MONITORING_ss2_m__0__HSIOM_GPIO)
    #define MONITORING_SS2_M_HSIOM_SEL_SPI    (MONITORING_ss2_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_SS2_PIN) */

#if (MONITORING_SPI_MASTER_SS3_PIN)
    #define MONITORING_SS3_M_HSIOM_REG    (*(reg32 *) MONITORING_ss3_m__0__HSIOM)
    #define MONITORING_SS3_M_HSIOM_PTR    ( (reg32 *) MONITORING_ss3_m__0__HSIOM)
    
    #define MONITORING_SS3_M_HSIOM_MASK      (MONITORING_ss3_m__0__HSIOM_MASK)
    #define MONITORING_SS3_M_HSIOM_POS       (MONITORING_ss3_m__0__HSIOM_SHIFT)
    #define MONITORING_SS3_M_HSIOM_SEL_GPIO  (MONITORING_ss3_m__0__HSIOM_GPIO)
    #define MONITORING_SS3_M_HSIOM_SEL_SPI   (MONITORING_ss3_m__0__HSIOM_SPI)
#endif /* (MONITORING_SPI_MASTER_SS3_PIN) */

#if (MONITORING_UART_RX_PIN)
    #define MONITORING_RX_HSIOM_REG   (*(reg32 *) MONITORING_rx__0__HSIOM)
    #define MONITORING_RX_HSIOM_PTR   ( (reg32 *) MONITORING_rx__0__HSIOM)
    
    #define MONITORING_RX_HSIOM_MASK      (MONITORING_rx__0__HSIOM_MASK)
    #define MONITORING_RX_HSIOM_POS       (MONITORING_rx__0__HSIOM_SHIFT)
    #define MONITORING_RX_HSIOM_SEL_GPIO  (MONITORING_rx__0__HSIOM_GPIO)
    #define MONITORING_RX_HSIOM_SEL_UART  (MONITORING_rx__0__HSIOM_UART)
#endif /* (MONITORING_UART_RX_PIN) */

#if (MONITORING_UART_RX_WAKE_PIN)
    #define MONITORING_RX_WAKE_HSIOM_REG   (*(reg32 *) MONITORING_rx_wake__0__HSIOM)
    #define MONITORING_RX_WAKE_HSIOM_PTR   ( (reg32 *) MONITORING_rx_wake__0__HSIOM)
    
    #define MONITORING_RX_WAKE_HSIOM_MASK      (MONITORING_rx_wake__0__HSIOM_MASK)
    #define MONITORING_RX_WAKE_HSIOM_POS       (MONITORING_rx_wake__0__HSIOM_SHIFT)
    #define MONITORING_RX_WAKE_HSIOM_SEL_GPIO  (MONITORING_rx_wake__0__HSIOM_GPIO)
    #define MONITORING_RX_WAKE_HSIOM_SEL_UART  (MONITORING_rx_wake__0__HSIOM_UART)
#endif /* (MONITORING_UART_WAKE_RX_PIN) */

#if (MONITORING_UART_CTS_PIN)
    #define MONITORING_CTS_HSIOM_REG   (*(reg32 *) MONITORING_cts__0__HSIOM)
    #define MONITORING_CTS_HSIOM_PTR   ( (reg32 *) MONITORING_cts__0__HSIOM)
    
    #define MONITORING_CTS_HSIOM_MASK      (MONITORING_cts__0__HSIOM_MASK)
    #define MONITORING_CTS_HSIOM_POS       (MONITORING_cts__0__HSIOM_SHIFT)
    #define MONITORING_CTS_HSIOM_SEL_GPIO  (MONITORING_cts__0__HSIOM_GPIO)
    #define MONITORING_CTS_HSIOM_SEL_UART  (MONITORING_cts__0__HSIOM_UART)
#endif /* (MONITORING_UART_CTS_PIN) */

#if (MONITORING_UART_TX_PIN)
    #define MONITORING_TX_HSIOM_REG   (*(reg32 *) MONITORING_tx__0__HSIOM)
    #define MONITORING_TX_HSIOM_PTR   ( (reg32 *) MONITORING_tx__0__HSIOM)
    
    #define MONITORING_TX_HSIOM_MASK      (MONITORING_tx__0__HSIOM_MASK)
    #define MONITORING_TX_HSIOM_POS       (MONITORING_tx__0__HSIOM_SHIFT)
    #define MONITORING_TX_HSIOM_SEL_GPIO  (MONITORING_tx__0__HSIOM_GPIO)
    #define MONITORING_TX_HSIOM_SEL_UART  (MONITORING_tx__0__HSIOM_UART)
#endif /* (MONITORING_UART_TX_PIN) */

#if (MONITORING_UART_RX_TX_PIN)
    #define MONITORING_RX_TX_HSIOM_REG   (*(reg32 *) MONITORING_rx_tx__0__HSIOM)
    #define MONITORING_RX_TX_HSIOM_PTR   ( (reg32 *) MONITORING_rx_tx__0__HSIOM)
    
    #define MONITORING_RX_TX_HSIOM_MASK      (MONITORING_rx_tx__0__HSIOM_MASK)
    #define MONITORING_RX_TX_HSIOM_POS       (MONITORING_rx_tx__0__HSIOM_SHIFT)
    #define MONITORING_RX_TX_HSIOM_SEL_GPIO  (MONITORING_rx_tx__0__HSIOM_GPIO)
    #define MONITORING_RX_TX_HSIOM_SEL_UART  (MONITORING_rx_tx__0__HSIOM_UART)
#endif /* (MONITORING_UART_RX_TX_PIN) */

#if (MONITORING_UART_RTS_PIN)
    #define MONITORING_RTS_HSIOM_REG      (*(reg32 *) MONITORING_rts__0__HSIOM)
    #define MONITORING_RTS_HSIOM_PTR      ( (reg32 *) MONITORING_rts__0__HSIOM)
    
    #define MONITORING_RTS_HSIOM_MASK     (MONITORING_rts__0__HSIOM_MASK)
    #define MONITORING_RTS_HSIOM_POS      (MONITORING_rts__0__HSIOM_SHIFT)    
    #define MONITORING_RTS_HSIOM_SEL_GPIO (MONITORING_rts__0__HSIOM_GPIO)
    #define MONITORING_RTS_HSIOM_SEL_UART (MONITORING_rts__0__HSIOM_UART)    
#endif /* (MONITORING_UART_RTS_PIN) */


/***************************************
*        Registers Constants
***************************************/

/* HSIOM switch values. */ 
#define MONITORING_HSIOM_DEF_SEL      (0x00u)
#define MONITORING_HSIOM_GPIO_SEL     (0x00u)
/* The HSIOM values provided below are valid only for MONITORING_CY_SCBIP_V0 
* and MONITORING_CY_SCBIP_V1. It is not recommended to use them for 
* MONITORING_CY_SCBIP_V2. Use pin name specific HSIOM constants provided 
* above instead for any SCB IP block version.
*/
#define MONITORING_HSIOM_UART_SEL     (0x09u)
#define MONITORING_HSIOM_I2C_SEL      (0x0Eu)
#define MONITORING_HSIOM_SPI_SEL      (0x0Fu)

/* Pins settings index. */
#define MONITORING_RX_WAKE_SCL_MOSI_PIN_INDEX   (0u)
#define MONITORING_RX_SCL_MOSI_PIN_INDEX       (0u)
#define MONITORING_TX_SDA_MISO_PIN_INDEX       (1u)
#define MONITORING_CTS_SCLK_PIN_INDEX       (2u)
#define MONITORING_RTS_SS0_PIN_INDEX       (3u)
#define MONITORING_SS1_PIN_INDEX                  (4u)
#define MONITORING_SS2_PIN_INDEX                  (5u)
#define MONITORING_SS3_PIN_INDEX                  (6u)

/* Pins settings mask. */
#define MONITORING_RX_WAKE_SCL_MOSI_PIN_MASK ((uint32) 0x01u << MONITORING_RX_WAKE_SCL_MOSI_PIN_INDEX)
#define MONITORING_RX_SCL_MOSI_PIN_MASK     ((uint32) 0x01u << MONITORING_RX_SCL_MOSI_PIN_INDEX)
#define MONITORING_TX_SDA_MISO_PIN_MASK     ((uint32) 0x01u << MONITORING_TX_SDA_MISO_PIN_INDEX)
#define MONITORING_CTS_SCLK_PIN_MASK     ((uint32) 0x01u << MONITORING_CTS_SCLK_PIN_INDEX)
#define MONITORING_RTS_SS0_PIN_MASK     ((uint32) 0x01u << MONITORING_RTS_SS0_PIN_INDEX)
#define MONITORING_SS1_PIN_MASK                ((uint32) 0x01u << MONITORING_SS1_PIN_INDEX)
#define MONITORING_SS2_PIN_MASK                ((uint32) 0x01u << MONITORING_SS2_PIN_INDEX)
#define MONITORING_SS3_PIN_MASK                ((uint32) 0x01u << MONITORING_SS3_PIN_INDEX)

/* Pin interrupt constants. */
#define MONITORING_INTCFG_TYPE_MASK           (0x03u)
#define MONITORING_INTCFG_TYPE_FALLING_EDGE   (0x02u)

/* Pin Drive Mode constants. */
#define MONITORING_PIN_DM_ALG_HIZ  (0u)
#define MONITORING_PIN_DM_DIG_HIZ  (1u)
#define MONITORING_PIN_DM_OD_LO    (4u)
#define MONITORING_PIN_DM_STRONG   (6u)


/***************************************
*          Macro Definitions
***************************************/

/* Return drive mode of the pin */
#define MONITORING_DM_MASK    (0x7u)
#define MONITORING_DM_SIZE    (3u)
#define MONITORING_GET_P4_PIN_DM(reg, pos) \
    ( ((reg) & (uint32) ((uint32) MONITORING_DM_MASK << (MONITORING_DM_SIZE * (pos)))) >> \
                                                              (MONITORING_DM_SIZE * (pos)) )

#if (MONITORING_TX_SDA_MISO_PIN)
    #define MONITORING_CHECK_TX_SDA_MISO_PIN_USED \
                (MONITORING_PIN_DM_ALG_HIZ != \
                    MONITORING_GET_P4_PIN_DM(MONITORING_uart_tx_i2c_sda_spi_miso_PC, \
                                                   MONITORING_uart_tx_i2c_sda_spi_miso_SHIFT))
#endif /* (MONITORING_TX_SDA_MISO_PIN) */

#if (MONITORING_RTS_SS0_PIN)
    #define MONITORING_CHECK_RTS_SS0_PIN_USED \
                (MONITORING_PIN_DM_ALG_HIZ != \
                    MONITORING_GET_P4_PIN_DM(MONITORING_uart_rts_spi_ss0_PC, \
                                                   MONITORING_uart_rts_spi_ss0_SHIFT))
#endif /* (MONITORING_RTS_SS0_PIN) */

/* Set bits-mask in register */
#define MONITORING_SET_REGISTER_BITS(reg, mask, pos, mode) \
                    do                                           \
                    {                                            \
                        (reg) = (((reg) & ((uint32) ~(uint32) (mask))) | ((uint32) ((uint32) (mode) << (pos)))); \
                    }while(0)

/* Set bit in the register */
#define MONITORING_SET_REGISTER_BIT(reg, mask, val) \
                    ((val) ? ((reg) |= (mask)) : ((reg) &= ((uint32) ~((uint32) (mask)))))

#define MONITORING_SET_HSIOM_SEL(reg, mask, pos, sel) MONITORING_SET_REGISTER_BITS(reg, mask, pos, sel)
#define MONITORING_SET_INCFG_TYPE(reg, mask, pos, intType) \
                                                        MONITORING_SET_REGISTER_BITS(reg, mask, pos, intType)
#define MONITORING_SET_INP_DIS(reg, mask, val) MONITORING_SET_REGISTER_BIT(reg, mask, val)

/* MONITORING_SET_I2C_SCL_DR(val) - Sets I2C SCL DR register.
*  MONITORING_SET_I2C_SCL_HSIOM_SEL(sel) - Sets I2C SCL HSIOM settings.
*/
/* SCB I2C: scl signal */
#if (MONITORING_CY_SCBIP_V0)
#if (MONITORING_I2C_PINS)
    #define MONITORING_SET_I2C_SCL_DR(val) MONITORING_scl_Write(val)

    #define MONITORING_SET_I2C_SCL_HSIOM_SEL(sel) \
                          MONITORING_SET_HSIOM_SEL(MONITORING_SCL_HSIOM_REG,  \
                                                         MONITORING_SCL_HSIOM_MASK, \
                                                         MONITORING_SCL_HSIOM_POS,  \
                                                         (sel))
    #define MONITORING_WAIT_SCL_SET_HIGH  (0u == MONITORING_scl_Read())

/* Unconfigured SCB: scl signal */
#elif (MONITORING_RX_WAKE_SCL_MOSI_PIN)
    #define MONITORING_SET_I2C_SCL_DR(val) \
                            MONITORING_uart_rx_wake_i2c_scl_spi_mosi_Write(val)

    #define MONITORING_SET_I2C_SCL_HSIOM_SEL(sel) \
                    MONITORING_SET_HSIOM_SEL(MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG,  \
                                                   MONITORING_RX_WAKE_SCL_MOSI_HSIOM_MASK, \
                                                   MONITORING_RX_WAKE_SCL_MOSI_HSIOM_POS,  \
                                                   (sel))

    #define MONITORING_WAIT_SCL_SET_HIGH  (0u == MONITORING_uart_rx_wake_i2c_scl_spi_mosi_Read())

#elif (MONITORING_RX_SCL_MOSI_PIN)
    #define MONITORING_SET_I2C_SCL_DR(val) \
                            MONITORING_uart_rx_i2c_scl_spi_mosi_Write(val)


    #define MONITORING_SET_I2C_SCL_HSIOM_SEL(sel) \
                            MONITORING_SET_HSIOM_SEL(MONITORING_RX_SCL_MOSI_HSIOM_REG,  \
                                                           MONITORING_RX_SCL_MOSI_HSIOM_MASK, \
                                                           MONITORING_RX_SCL_MOSI_HSIOM_POS,  \
                                                           (sel))

    #define MONITORING_WAIT_SCL_SET_HIGH  (0u == MONITORING_uart_rx_i2c_scl_spi_mosi_Read())

#else
    #define MONITORING_SET_I2C_SCL_DR(val)        do{ /* Does nothing */ }while(0)
    #define MONITORING_SET_I2C_SCL_HSIOM_SEL(sel) do{ /* Does nothing */ }while(0)

    #define MONITORING_WAIT_SCL_SET_HIGH  (0u)
#endif /* (MONITORING_I2C_PINS) */

/* SCB I2C: sda signal */
#if (MONITORING_I2C_PINS)
    #define MONITORING_WAIT_SDA_SET_HIGH  (0u == MONITORING_sda_Read())
/* Unconfigured SCB: sda signal */
#elif (MONITORING_TX_SDA_MISO_PIN)
    #define MONITORING_WAIT_SDA_SET_HIGH  (0u == MONITORING_uart_tx_i2c_sda_spi_miso_Read())
#else
    #define MONITORING_WAIT_SDA_SET_HIGH  (0u)
#endif /* (MONITORING_MOSI_SCL_RX_PIN) */
#endif /* (MONITORING_CY_SCBIP_V0) */

/* Clear UART wakeup source */
#if (MONITORING_RX_SCL_MOSI_PIN)
    #define MONITORING_CLEAR_UART_RX_WAKE_INTR        do{ /* Does nothing */ }while(0)
    
#elif (MONITORING_RX_WAKE_SCL_MOSI_PIN)
    #define MONITORING_CLEAR_UART_RX_WAKE_INTR \
            do{                                      \
                (void) MONITORING_uart_rx_wake_i2c_scl_spi_mosi_ClearInterrupt(); \
            }while(0)

#elif(MONITORING_UART_RX_WAKE_PIN)
    #define MONITORING_CLEAR_UART_RX_WAKE_INTR \
            do{                                      \
                (void) MONITORING_rx_wake_ClearInterrupt(); \
            }while(0)
#else
#endif /* (MONITORING_RX_SCL_MOSI_PIN) */


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Unconfigured pins */
#define MONITORING_REMOVE_MOSI_SCL_RX_WAKE_PIN    MONITORING_REMOVE_RX_WAKE_SCL_MOSI_PIN
#define MONITORING_REMOVE_MOSI_SCL_RX_PIN         MONITORING_REMOVE_RX_SCL_MOSI_PIN
#define MONITORING_REMOVE_MISO_SDA_TX_PIN         MONITORING_REMOVE_TX_SDA_MISO_PIN
#ifndef MONITORING_REMOVE_SCLK_PIN
#define MONITORING_REMOVE_SCLK_PIN                MONITORING_REMOVE_CTS_SCLK_PIN
#endif /* MONITORING_REMOVE_SCLK_PIN */
#ifndef MONITORING_REMOVE_SS0_PIN
#define MONITORING_REMOVE_SS0_PIN                 MONITORING_REMOVE_RTS_SS0_PIN
#endif /* MONITORING_REMOVE_SS0_PIN */

/* Unconfigured pins */
#define MONITORING_MOSI_SCL_RX_WAKE_PIN   MONITORING_RX_WAKE_SCL_MOSI_PIN
#define MONITORING_MOSI_SCL_RX_PIN        MONITORING_RX_SCL_MOSI_PIN
#define MONITORING_MISO_SDA_TX_PIN        MONITORING_TX_SDA_MISO_PIN
#ifndef MONITORING_SCLK_PIN
#define MONITORING_SCLK_PIN               MONITORING_CTS_SCLK_PIN
#endif /* MONITORING_SCLK_PIN */
#ifndef MONITORING_SS0_PIN
#define MONITORING_SS0_PIN                MONITORING_RTS_SS0_PIN
#endif /* MONITORING_SS0_PIN */

#if (MONITORING_MOSI_SCL_RX_WAKE_PIN)
    #define MONITORING_MOSI_SCL_RX_WAKE_HSIOM_REG     MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_WAKE_HSIOM_PTR     MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_WAKE_HSIOM_MASK    MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_WAKE_HSIOM_POS     MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG

    #define MONITORING_MOSI_SCL_RX_WAKE_INTCFG_REG    MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_WAKE_INTCFG_PTR    MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG

    #define MONITORING_MOSI_SCL_RX_WAKE_INTCFG_TYPE_POS   MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_WAKE_INTCFG_TYPE_MASK  MONITORING_RX_WAKE_SCL_MOSI_HSIOM_REG
#endif /* (MONITORING_RX_WAKE_SCL_MOSI_PIN) */

#if (MONITORING_MOSI_SCL_RX_PIN)
    #define MONITORING_MOSI_SCL_RX_HSIOM_REG      MONITORING_RX_SCL_MOSI_HSIOM_REG
    #define MONITORING_MOSI_SCL_RX_HSIOM_PTR      MONITORING_RX_SCL_MOSI_HSIOM_PTR
    #define MONITORING_MOSI_SCL_RX_HSIOM_MASK     MONITORING_RX_SCL_MOSI_HSIOM_MASK
    #define MONITORING_MOSI_SCL_RX_HSIOM_POS      MONITORING_RX_SCL_MOSI_HSIOM_POS
#endif /* (MONITORING_MOSI_SCL_RX_PIN) */

#if (MONITORING_MISO_SDA_TX_PIN)
    #define MONITORING_MISO_SDA_TX_HSIOM_REG      MONITORING_TX_SDA_MISO_HSIOM_REG
    #define MONITORING_MISO_SDA_TX_HSIOM_PTR      MONITORING_TX_SDA_MISO_HSIOM_REG
    #define MONITORING_MISO_SDA_TX_HSIOM_MASK     MONITORING_TX_SDA_MISO_HSIOM_REG
    #define MONITORING_MISO_SDA_TX_HSIOM_POS      MONITORING_TX_SDA_MISO_HSIOM_REG
#endif /* (MONITORING_MISO_SDA_TX_PIN_PIN) */

#if (MONITORING_SCLK_PIN)
    #ifndef MONITORING_SCLK_HSIOM_REG
    #define MONITORING_SCLK_HSIOM_REG     MONITORING_CTS_SCLK_HSIOM_REG
    #define MONITORING_SCLK_HSIOM_PTR     MONITORING_CTS_SCLK_HSIOM_PTR
    #define MONITORING_SCLK_HSIOM_MASK    MONITORING_CTS_SCLK_HSIOM_MASK
    #define MONITORING_SCLK_HSIOM_POS     MONITORING_CTS_SCLK_HSIOM_POS
    #endif /* MONITORING_SCLK_HSIOM_REG */
#endif /* (MONITORING_SCLK_PIN) */

#if (MONITORING_SS0_PIN)
    #ifndef MONITORING_SS0_HSIOM_REG
    #define MONITORING_SS0_HSIOM_REG      MONITORING_RTS_SS0_HSIOM_REG
    #define MONITORING_SS0_HSIOM_PTR      MONITORING_RTS_SS0_HSIOM_PTR
    #define MONITORING_SS0_HSIOM_MASK     MONITORING_RTS_SS0_HSIOM_MASK
    #define MONITORING_SS0_HSIOM_POS      MONITORING_RTS_SS0_HSIOM_POS
    #endif /* MONITORING_SS0_HSIOM_REG */
#endif /* (MONITORING_SS0_PIN) */

#define MONITORING_MOSI_SCL_RX_WAKE_PIN_INDEX MONITORING_RX_WAKE_SCL_MOSI_PIN_INDEX
#define MONITORING_MOSI_SCL_RX_PIN_INDEX      MONITORING_RX_SCL_MOSI_PIN_INDEX
#define MONITORING_MISO_SDA_TX_PIN_INDEX      MONITORING_TX_SDA_MISO_PIN_INDEX
#ifndef MONITORING_SCLK_PIN_INDEX
#define MONITORING_SCLK_PIN_INDEX             MONITORING_CTS_SCLK_PIN_INDEX
#endif /* MONITORING_SCLK_PIN_INDEX */
#ifndef MONITORING_SS0_PIN_INDEX
#define MONITORING_SS0_PIN_INDEX              MONITORING_RTS_SS0_PIN_INDEX
#endif /* MONITORING_SS0_PIN_INDEX */

#define MONITORING_MOSI_SCL_RX_WAKE_PIN_MASK MONITORING_RX_WAKE_SCL_MOSI_PIN_MASK
#define MONITORING_MOSI_SCL_RX_PIN_MASK      MONITORING_RX_SCL_MOSI_PIN_MASK
#define MONITORING_MISO_SDA_TX_PIN_MASK      MONITORING_TX_SDA_MISO_PIN_MASK
#ifndef MONITORING_SCLK_PIN_MASK
#define MONITORING_SCLK_PIN_MASK             MONITORING_CTS_SCLK_PIN_MASK
#endif /* MONITORING_SCLK_PIN_MASK */
#ifndef MONITORING_SS0_PIN_MASK
#define MONITORING_SS0_PIN_MASK              MONITORING_RTS_SS0_PIN_MASK
#endif /* MONITORING_SS0_PIN_MASK */

#endif /* (CY_SCB_PINS_MONITORING_H) */


/* [] END OF FILE */
